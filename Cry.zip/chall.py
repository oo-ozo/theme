import string
#from secret import MSG

ct = []
msg = "hello"
for char in msg:
    ct.append((123 * char + 18) % 256)

encryption(2838)
'''
ct = encryption(MSG)
f = open('./msg.enc','w')
f.write(ct.hex())
f.close()'''


